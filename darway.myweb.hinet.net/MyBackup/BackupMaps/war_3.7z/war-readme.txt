*war_3 file informaion*
=======================================
Title			: DSV3-War
Filename		: war_3.wad
Other files included	: stealfka.wad(skin), warallies.wad(optional feature)
Engine Required		: Prboom 2.1.1,MBF,Boom, and any other Boom supporting Engine
Engine not supported	: Zdoom, Legacy, Edge
Author			: Samuel A. Villarreal
Email Address		: stealfka@hotmail.com
Misc. Author Info	: Currently making levels for Fredrik Johansson's Pain project.
Tools used		: Deepsea 10.20b, Mspaint, Wintex, Rmb, Inkworks, Dehacked
Base			: All levels from scratch except for Map32-used E1m1 of Doom.
Known Bugs		: Found none so far. Email me if find any.
Other wads by author	: Dsv, Blackness
Credits			: Chris "Dragon" Pisarczyk, Team Tnt, Id software, Metallica
Big fuck you to		: Everyone at my school
=======================================
*Play Information*

Level #			: Map01-32
Single Player		: Yes
Cooperative 2-8 Player	: Yes
Deathmatch 2-10 Player	: Yes-Not tested, 12 Players for Skulltag
Difficulty Settings	: Yes-Might be easy on UV but it might be challenging.
New Sounds		: Yes-Quake 3 sounds from Chris Pisarczyk's wad.
New Graphics		: Yes-Quake 3 graphics from Chris Pisarczyk's wad and some Plutonia
			  and Eternal graphics as well with some of my own. And a new boss
			  from a monster from Half-Life.
New Music		: Yes-Some from Icarus.wad, Doom, Doom2, Tnt, and Ty Halderman's
			  Pax.wad. Map01 music by Peter Cowderoy, Map04 and 21 music by
			  Kniggit. Map32 music from Skulltag.wad
Demos Replaced		: Yes
Bulid time		: Started on August 2, 2000 and finished on December 20, 2000.
Wad Description		: 32 tough levels that were inspired by Plutonia, Momento Mori and
			  Icraus. The levels aren't super detailed like Darkening or
			  Eternal but just as good as Doom and Doom 2's levels. This is the
			  third and final installment of the Dsv series with better detail
			  from my previous two wads. Like my previous work, I like to add
			  new weapon graphics from Unreal, Quake2, and Blood to replace the 		          boring ones. There are some deh modified stuff like the Big Brain
			  (which takes more damage). There is also a new boss that replaces
			  the SSwolf guy. The cheats are changed so no one will cheat. But
			  the script.deh file can be opened by notepad to view the cheats.
Story			: If you are not interested in this sort of stuff then skip this
			  part. After Stealfka's army have been put to a halt during 
			  Blackness by one of his own servants, everything has died off and
			  peace was restored. After you deafeated Dsv during the Dsv.wad you
			  went back to Uac headquaters, now repaired by technicians. One of
			  the scientist showed you a Demon that survived your onslaught. It
			  wasn't attacking which surprised you. The scientist manage to 
			  create clones of the demons and made them into helpful allies. 
			  The scientists manage to get a hold of a Revenant and a
			  Chaingunner as well. Not caring you went back to the couch to 			  sleep (which you deeply deserve). But then something happened,
			  you heard a explosion. "Not them again! Shit! when can I get a 
			  break!" you mumbled to yourself. A Imp came charging its way in
			  your room and as you reached your pistol, one of those Demons
			  that were held by the scientists attacked the Imp. One of the 
			  remaining scientists pinpointed the location of the invasion.
			  It seems that Dsv revived Stealfka and now both are restarting
			  the invasion. Two gate keepers are holding the key to the location
			  of Dsv and Stealfka and you must find them. From Uac base to the
			  outskirts of broken down cities to the hidden village in South
			  America, you and the new allies must fight once more to once agian 		          save the world from Dsv and Stealfka's reign of terror. Luckily, 			  you might have some reinforcements once a while.
Gameplay		: War has a lot of tricky things like a door opening and not
			  knowing. 
			  There are three allies, a red Demon, and a strong Revenant and
			  Chaingunner. The Revenant and Chaingunner might get mixed up with
			  the evil versions so be careful. Sometimes you can find good
			  versions of other monsters too, especially a good Cyberdemon, if
			  you are lucky to find one! Allies are always behind bars or glass
			  sealed rooms. Just shoot the glass to release them. If you shoot 
			  them, then they will shoot you back so be careful. The allies
			  feature is not found on the oringinal war_3 file but its on a 
			  optional file called warallies.wad so if you don't want the allies
			  then just load war_3.wad by itself.
Troubleshooting		: There are times that you will get stuck or stumted on a puzzle or
			  trap. This might be a bug or part of the puzzle but before you
			  email me please check the following: Search for wierd textures,
			  shoot everywhere, backtrack for any new open doors, backtrack 
			  to see any new keys or items that teleported in.
Email me!		: Email me telling me what you think! I want this wad to be perfect
			  so tell me what's missing or if it was too easy or errors etc.
Send me demos!!!!	: Send me demos of your talent! I really want some demos of map32
			  (its really hard) on Nightmare. But I like demos of other levels
			  as well! 
Zdoom correction	: To play this wad on Zdoom, you need Wintex to delete the m_doom 
			  and cwil.lmps. But the levels still might not function properly.
			  
Where to find this wad	: www.teamtnt.com or somewhere in ftp:cdrom.com

I hope you will enjoy this wad, I put a lot of stress and time on this one:)
			  
			    
* Copyright / Permissions *

Authors may NOT use the levels as a base to build additional
levels. BUT may use the resource like graphics and stuff for
other wads.  
You MAY not distribute this WAD file for profit.
