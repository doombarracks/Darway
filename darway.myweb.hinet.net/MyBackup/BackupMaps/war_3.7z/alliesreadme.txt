warallies wad information
========================
This wad contains some maps with "good" monsters that will help (or just get in your way) 
your mission. Just load this wad with war_3.wad. If nothing happens, email me to let me know.

Credits: Skulltag for the Red Demon graphics. And Greg Lewis for dehacked (for making the
other two).

NOTE: Some of the levels are early versions and might be different than from the ones on
war_3.wad