


                            MR.ROCKET'S QUAKE III "the longest yard " REMAKE



==================================================================================================



Misc. Author Info : MADE TO BE USED WITH DOOM LEGACY 
and LEGACY'S new editing features 

 THIS ONE ALSO USING CORONAL COLORED LIGHTING ,3DFLOORS,SWIMMIBLE WATER

~
 Description : 4 player DM , q3 tc style map with jump pads


USING THE LATEST VERSION OF DOOM2.WAD and DOOM LEGACY with  ,OpenGL modes..
it still runs in software but designed around GL in mind..
Credits to : ID SOFTWARE for making an awesome game! 
THE DOOM LEGACY TEAM for making and awesome port! 
also the guys that made the EDITORS I used!
 

Credits for play testing :
not in any particular order..

   Grenes
   Exl
   Grunt
   Rellik
   Agent Spork
   Dagger
   Props
   Exp


Additional Credits to : 

   Exl and Rellik for optimizing the script

   ID's Tim Willits for makeing the q3 map

          THANKS YOU GUYS ! 



================================================================

* Play Information *
Play tested on : DOOM LEGACY 1.40 final and 1.41rc2 non public version.

public versions can be found here : http://legacy.newdoom.com/


Episode and Level # : DOOM2 MAP01
Single Player : for a look
Cooperative no
Deathmatch 2-4x8 Player : yes
Difficulty Settings : yes
New Sounds : yes - mostly q3 sound fx
New Graphics : yes - some sprites and textures which can be found in the q3texful.zip
New Music : yes -  sound fx wav , script enabled
Demos Replaced : no
Secrets : yes 



 
========================================================================

                             ? MRQ3DM.CFG ?

========================================================================




place the MRQ3DM.cfg in your legacy root directory , e.g. c:\games\legacy

* please read the enclosed ZOOMREADME.txt for more infomation. 




========================================================================


* Construction *
 Base : based off the q3 map " the longest yard" - Q3 console cvar /MAP Q3DM17

 Time : about 3 weeks :p  real time about 10 hours


Editor(s) used : (wad author 1.30) , wintex 4.3 , XWE , (zenode1.0.10)
Known Bugs : in software mode , legacy doesnt display clear cyan texture correctly ,made for opengl..
             the map "may" run a little slow on slower systems running at 200mhz or below 


* Copyright / Permissions *
Authors (may NOT) use this level as a base to build additional levels. 

 

that's it !   , happy fraggin !!! ;)

 

 (One of the following)

You MAY distribute this WAD, provided you include this file, with
no modifications. You may distribute this file in any electronic
format (BBS, Internet, Diskette, CD, etc) as long as you include this file and its config.



~ MR.ROCKET



