




========================================================================================================

           Place the MRQ3DM.cfg in your  (  legacy root directory , e.g. c:\games\legacy )

--------------------------------------------------------------------------------------------------------

       the default ZOOM key is "W" , use it to ZOOM , press W to zoom , press it again to zoom out.

========================================================================================================




just like what was in the autoece.cfg accept this config is enabled minus the ///.

mostly what the config was for was to be able to have a zoom key pre binded 
so everyone will have a zoom view in the map..

the config also disables or mutes the midi music for the map because its music is played as a soundfx.
these 2 config vars. will only be executed when running this map , unless you wanted to use cvar exec MRQ3DM.cfg 
so it would run on a different map , you can do that to :)




------------------------------------------------------------------

the default ZOOM key is W , if wanting a different key as your ZOOM key you can freely 
edit the MRQ3DM.cfg and change the key binding there..
just look for the W's  :)



                                  

                                      s. -=MR.ROCKET>
